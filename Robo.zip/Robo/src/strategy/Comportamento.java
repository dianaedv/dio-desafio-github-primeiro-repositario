package strategy;

public interface Comportamento {
	void mover();
}
