package banco;

public class ContaEspecial extends ContaBancaria {
    public ContaEspecial(String t, int a, int n, double s){
        super(t, a, n, s);
    }
    protected int limite_Da_Conta;
    
    public void sacar(double valor, double limite_Da_Conta){
        if(valor > (limite_Da_Conta + saldo)){
            System.out.println("Saldo insuficiente");
        } else {
            this.saldo -= valor;
        }
    }
      
}
