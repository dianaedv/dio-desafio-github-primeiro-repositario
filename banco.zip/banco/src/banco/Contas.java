package banco;

public class Contas {

    public static void main(String[] args) {
        //Incluir dados do Cliente 1 na conta especial e posteriormente na conta poupança
        ContaEspecial contaespecial1 = new ContaEspecial("Maria Mendes", 1, 390178, 500.00);
        ContaPoupança contapoupança1 = new ContaPoupança("Pedro Peres", 1, 871093, 5000.00);
        
        //Cliente 1 saca na conta especial
        contaespecial1.sacar(100.00, 400.00);
        //System.out.println(contaespecial1.cliente);
        //System.out.println(contaespecial1.saldo);
           
        //Cliente 1 saca na conta poupança
        contapoupança1.sacar(1000.00);
        //System.out.println(contapoupança1.cliente);
        //System.out.println(contapoupança1.saldo);
        
        //Novo saldo do Cliente 1 apos o dia do rendimento com taxa de 50%
        contapoupança1.calcularNovoSaldo(20, 20, (float) 0.15);
        System.out.println(contapoupança1.saldo);
        
        //Cliente 1 transfere ao cliente da conta 2
        contaespecial1.transferir(100, contapoupança1);
        
        //Dados das contas do Cliente 1
        System.out.println("Dados da Conta Especial do Cliente : " +contaespecial1.titular);
        System.out.println("Agencia: " +contaespecial1.agencia + "  Conta: " +contaespecial1.num_conta + "  Saldo: " +contaespecial1.saldo);
        System.out.println("---------------------------------------------------------------------");
        System.out.println("Dados da Conta Poupança do Cliente : " +contapoupança1.titular);
        System.out.println("Agencia: " +contapoupança1.agencia + "  Conta: " +contapoupança1.num_conta + "  Saldo: " +contapoupança1.saldo);
    }
    
}
