package banco;

public class ContaPoupança extends ContaBancaria{
    public ContaPoupança(String t, int a, int n, double s){
        super(t, a, n, s);
    }
    protected int dia_De_Rendimento;
    protected float taxa_De_Rendimento;
    protected int diaAtual;    
    
    public void calcularNovoSaldo(int diaAtual, int dia_De_Rendimento, float taxa_De_Rendimento){
        if(diaAtual == dia_De_Rendimento){
            this.saldo = this.saldo + (this.saldo * (float) taxa_De_Rendimento);
            //System.out.println(saldo);
        }else{
            System.out.println("Aguarde...");
        }
    }
}
 