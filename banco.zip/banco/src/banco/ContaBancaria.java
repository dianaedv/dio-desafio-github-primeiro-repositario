package banco;

public abstract class ContaBancaria {
	protected String titular;
    protected int agencia;
    protected int num_conta;
    protected double saldo;
 
    ContaBancaria(String t, int a, int n, double s){
        titular = t;
    	agencia = a;
        num_conta = n;
        saldo = s;
    }
    public void sacar(double valor){
        if(valor > this.saldo){
            System.out.println("Saldo insuficiente");
        }else{
            this.saldo -= valor;
        }
    }
    public void depositar(double valor){
        if(valor < 0){
            System.out.println("Valor deve ser positivo");
        }else{
            this.saldo += valor;
        }
    } 
    public void transferir(double valor, ContaBancaria contaDestino){
    	if(valor < 0){
            System.out.println("Valor deve ser positivo");
        }else{
        	this.sacar(valor);
            contaDestino.depositar(valor);
        }
    }       
    }

